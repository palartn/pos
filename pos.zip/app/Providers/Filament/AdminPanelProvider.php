<?php

namespace App\Providers\Filament;

use App\Filament\Pages\PosScreen;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Pages;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\View\PanelsRenderHook;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReceiptController;
use App\Http\Controllers\VoucherController;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function boot(): void
    {
        // طباعة إيصال الفاتورة (يتحقق المتحكم من الدخول والصلاحية)
        Route::middleware('web')->get('receipts/{sale}', [ReceiptController::class, 'show'])->name('receipts.show');
        Route::middleware('web')->get('vouchers/{voucher}', [VoucherController::class, 'show'])->name('vouchers.show');
    }

    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->brandName('إدارة السوبر ماركت')
            ->font('Cairo')
            ->colors(['primary' => Color::Emerald])
            ->sidebarCollapsibleOnDesktop()
            ->navigationGroups(['المبيعات', 'الخزينة والورديات', 'المشتريات', 'العملاء والموردون', 'المخزون', 'الموظفون', 'التقارير', 'الإدارة'])
            ->renderHook(
                PanelsRenderHook::HEAD_END,
                fn (): string => '<link rel="stylesheet" href="' . asset('css/reports.css') . '?v=' . (@filemtime(public_path('css/reports.css')) ?: 1) . '">',
            )
            ->renderHook(
                PanelsRenderHook::HEAD_END,
                fn (): string => '<link rel="stylesheet" href="' . asset('css/pos.css') . '?v=' . (@filemtime(public_path('css/pos.css')) ?: 1) . '">',
                scopes: PosScreen::class,
            )
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\\Filament\\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\\Filament\\Pages')
            ->pages([
                Pages\Dashboard::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\\Filament\\Widgets')
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }
}
