<?php

namespace App\Models;

use App\Enums\PaymentMethod;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;

class CashierShift extends Model
{
    protected $fillable = [
        'user_id', 'opened_at', 'closed_at', 'opening_cash',
        'expected_cash', 'counted_cash', 'difference', 'status', 'notes',
    ];

    protected $casts = [
        'opened_at' => 'datetime',
        'closed_at' => 'datetime',
        'opening_cash' => 'decimal:2',
        'expected_cash' => 'decimal:2',
        'counted_cash' => 'decimal:2',
        'difference' => 'decimal:2',
    ];

    public static function openFor(?int $userId): ?self
    {
        if (! $userId) {
            return null;
        }

        return static::where('user_id', $userId)->where('status', 'open')->latest('id')->first();
    }

    public function isOpen(): bool
    {
        return $this->status === 'open';
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function sales(): HasMany
    {
        return $this->hasMany(Sale::class, 'shift_id');
    }

    public function cashMovements(): HasMany
    {
        return $this->hasMany(CashMovement::class, 'shift_id');
    }

    /** إغلاق الوردية: يرجع الفرق (المعدود − المتوقع) أو null إن كانت مغلقة مسبقاً */
    public function closeWith(float $counted, ?string $notes = null): ?float
    {
        return DB::transaction(function () use ($counted, $notes) {
            $shift = static::whereKey($this->id)->lockForUpdate()->first();

            if (! $shift->isOpen()) {
                return null;
            }

            $expected = $shift->summary()['expected_cash'];
            $counted = round($counted, 2);
            $diff = round($counted - $expected, 2);

            $shift->update([
                'status' => 'closed',
                'closed_at' => now(),
                'expected_cash' => $expected,
                'counted_cash' => $counted,
                'difference' => $diff,
                'notes' => $notes,
            ]);

            $this->refresh();

            return $diff;
        });
    }

    /** ملخص الوردية والنقد المتوقع في الدرج */
    public function summary(): array
    {
        $id = $this->id;

        $byMethod = Sale::where('shift_id', $id)
            ->selectRaw('payment_method, COUNT(*) as c, SUM(total) as t, SUM(paid) as p, SUM(due_amount) as d')
            ->groupBy('payment_method')
            ->get()
            ->map(fn ($r) => [
                'label' => PaymentMethod::tryFrom($r->payment_method)?->label() ?? $r->payment_method,
                'count' => (int) $r->c,
                'total' => (float) $r->t,
                'paid' => (float) $r->p,
                'due' => (float) $r->d,
            ])->all();

        $cashSales = (float) Sale::where('shift_id', $id)->where('payment_method', 'cash')->sum('paid');

        $customerCash = (float) CustomerTransaction::where('shift_id', $id)
            ->where('type', 'payment')->where('payment_method', 'cash')->sum('amount');

        $customerReversals = (float) CustomerTransaction::where('shift_id', $id)
            ->where('type', 'debt')->where('payment_method', 'cash')->sum('amount');

        $supplierCash = (float) SupplierTransaction::where('shift_id', $id)
            ->where('type', 'payment')->where('payment_method', 'cash')->sum('amount');

        $saleRefunds = (float) SaleReturn::where('shift_id', $id)->where('refund_method', 'cash')->sum('cash_refund');

        $income = (float) CashMovement::where('shift_id', $id)->where('type', 'income')->sum('amount');
        $expense = (float) CashMovement::where('shift_id', $id)->where('type', 'expense')->sum('amount');

        $opening = (float) $this->opening_cash;

        return [
            'opening_cash' => $opening,
            'sales_count' => array_sum(array_column($byMethod, 'count')),
            'sales_total' => array_sum(array_column($byMethod, 'total')),
            'by_method' => $byMethod,
            'cash_sales' => $cashSales,
            'customer_cash' => $customerCash,
            'customer_cash_reversals' => $customerReversals,
            'supplier_cash' => $supplierCash,
            'income' => $income,
            'expense' => $expense,
            'sale_refunds' => $saleRefunds,
            'expected_cash' => round($opening + $cashSales + $customerCash - $customerReversals + $income - $supplierCash - $expense - $saleRefunds, 2),
        ];
    }
}
